import { useState, useEffect, useRef } from "react";
import { Search, Car, MapPin, Clock, X, Filter, Eye, Upload, Image, Zap, Activity } from "lucide-react";
import Sidebar from "../../../components/Layout/Sidebar";
import Header from "../../../components/Layout/Header";



interface VehicleInfo {
  brand: string;
  licensePlate: string;
  color: string;
  searchImage?: File | null;
}

interface CameraDetection {
  id: string | number;
  name: string;
  location: string;
  detectionTime: string;
  thumbnail: string;
  confidence: number;
  vehicleImage: string;
}

interface TrackingResult {
  vehicle: VehicleInfo;
  detections: CameraDetection[];
  totalCameras: number;
  lastSeen: string;
  status: 'tracking' | 'found' | 'not_found';
  searchMethod: 'text' | 'image';
}

export default function VehicleTrackingDashboard() {
  const [vehicleInfo, setVehicleInfo] = useState<VehicleInfo>({
    brand: '',
    licensePlate: '',
    color: '',
    searchImage: null
  });
  
  const [isTracking, setIsTracking] = useState(false);
  const [trackingResults, setTrackingResults] = useState<TrackingResult | null>(null);
  const [searchHistory, setSearchHistory] = useState<VehicleInfo[]>([]);
  const [searchMethod, setSearchMethod] = useState<'text' | 'image'>('text');
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Mock data cho demo
  const mockCameras = [
    { id: 1, name: "Main Entrance", location: "Building A - Gate 1", thumbnail: "/api/placeholder/400/300" },
    { id: 2, name: "Parking Zone A", location: "North Side - Level 1", thumbnail: "/api/placeholder/400/300" },
    { id: 3, name: "Security Checkpoint", location: "Building B - Reception", thumbnail: "/api/placeholder/400/300" },
    { id: 4, name: "Loading Bay", location: "Warehouse - Dock 3", thumbnail: "/api/placeholder/400/300" },
    { id: 5, name: "Exit Terminal", location: "South Gate - Lane 2", thumbnail: "/api/placeholder/400/300" },
    { id: 6, name: "VIP Parking", location: "Executive Block", thumbnail: "/api/placeholder/400/300" }
  ];

  const handleInputChange = (field: keyof VehicleInfo, value: string) => {
    setVehicleInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleImageUpload = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      setVehicleInfo(prev => ({
        ...prev,
        searchImage: file
      }));
      setSearchMethod('image');
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageUpload(e.dataTransfer.files[0]);
    }
  };

  const simulateTracking = async (vehicle: VehicleInfo, method: 'text' | 'image'): Promise<TrackingResult> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock detection logic - randomly select 2-6 cameras
    const numDetections = Math.floor(Math.random() * 5) + 2;
    const selectedCameras = mockCameras
      .sort(() => Math.random() - 0.5)
      .slice(0, numDetections);
    
    const detections: CameraDetection[] = selectedCameras.map((camera, index) => ({
      ...camera,
      detectionTime: new Date(Date.now() - (index * 15 * 60 * 1000)).toISOString(),
      confidence: Math.floor(Math.random() * 30) + 70,
      vehicleImage: `/api/placeholder/300/200?vehicle=${index}`
    }));

    return {
      vehicle,
      detections: detections.sort((a, b) => new Date(b.detectionTime).getTime() - new Date(a.detectionTime).getTime()),
      totalCameras: detections.length,
      lastSeen: detections[0]?.detectionTime || new Date().toISOString(),
      status: detections.length > 0 ? 'found' : 'not_found',
      searchMethod: method
    };
  };

  const handleTrackVehicle = async () => {
    if (searchMethod === 'text' && !vehicleInfo.licensePlate.trim()) {
      alert('Please enter license plate number or upload an image');
      return;
    }
    
    if (searchMethod === 'image' && !vehicleInfo.searchImage) {
      alert('Please upload an image to search');
      return;
    }

    setIsTracking(true);
    setTrackingResults(null);

    try {
      const results = await simulateTracking(vehicleInfo, searchMethod);
      setTrackingResults(results);
      
      // Add to search history (only for text searches)
      if (searchMethod === 'text' && vehicleInfo.licensePlate) {
        setSearchHistory(prev => {
          const filtered = prev.filter(item => item.licensePlate !== vehicleInfo.licensePlate);
          return [vehicleInfo, ...filtered].slice(0, 5);
        });
      }
    } catch (error) {
      console.error('Tracking failed:', error);
    } finally {
      setIsTracking(false);
    }
  };

  const clearSearch = () => {
    setVehicleInfo({ brand: '', licensePlate: '', color: '', searchImage: null });
    setTrackingResults(null);
  };

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const useHistorySearch = (historyItem: VehicleInfo) => {
    setVehicleInfo(historyItem);
    setSearchMethod('text');
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar defaultActiveItem="vehicles" />
      
      <div className="flex flex-col flex-grow overflow-hidden">
        <Header title="Vehicle Tracking System" />
        
        <div className="flex-1 overflow-auto p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Active Cameras</p>
                  <p className="text-2xl font-bold">{mockCameras.length}</p>
                </div>
                <Eye className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Vehicles Tracked</p>
                  <p className="text-2xl font-bold">1,247</p>
                </div>
                <Car className="w-8 h-8 text-green-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Detection Rate</p>
                  <p className="text-2xl font-bold">94.2%</p>
                </div>
                <Zap className="w-8 h-8 text-purple-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Live Tracking</p>
                  <p className="text-2xl font-bold">23</p>
                </div>
                <Activity className="w-8 h-8 text-orange-200" />
              </div>
            </div>
          </div>

          {/* Search Section */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Search className="w-4 h-4 text-white" />
                </div>
                Vehicle Search
              </h2>
              
              {/* Search Method Toggle */}
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setSearchMethod('text')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    searchMethod === 'text'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Text Search
                </button>
                <button
                  onClick={() => setSearchMethod('image')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    searchMethod === 'image'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Image Search
                </button>
              </div>
            </div>

            {searchMethod === 'text' ? (
              /* Text Search Form */
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700">
                      License Plate *
                    </label>
                    <input
                      type="text"
                      value={vehicleInfo.licensePlate}
                      onChange={(e) => handleInputChange('licensePlate', e.target.value.toUpperCase())}
                      placeholder="e.g., 29A-12345"
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Vehicle Brand
                    </label>
                    <input
                      type="text"
                      value={vehicleInfo.brand}
                      onChange={(e) => handleInputChange('brand', e.target.value)}
                      placeholder="e.g., Toyota, Honda"
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Color
                    </label>
                    <select
                      value={vehicleInfo.color}
                      onChange={(e) => handleInputChange('color', e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                    >
                      <option value="">Select Color</option>
                      <option value="white">White</option>
                      <option value="black">Black</option>
                      <option value="silver">Silver</option>
                      <option value="red">Red</option>
                      <option value="blue">Blue</option>
                      <option value="gray">Gray</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
              </div>
            ) : (
              /* Image Search Form */
              <div className="space-y-6">
                <div
                  className={`relative border-2 border-dashed rounded-lg p-8 transition-all ${
                    dragActive
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
                    className="hidden"
                  />
                  
                  {vehicleInfo.searchImage ? (
                    <div className="text-center">
                      <div className="inline-block relative">
                        <img
                          src={URL.createObjectURL(vehicleInfo.searchImage)}
                          alt="Search vehicle"
                          className="max-h-32 rounded-lg shadow-md"
                        />
                        <button
                          onClick={() => setVehicleInfo(prev => ({ ...prev, searchImage: null }))}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
                        >
                          <X size={14} />
                        </button>
                      </div>
                      <p className="text-sm text-gray-600 mt-2">{vehicleInfo.searchImage.name}</p>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-700 mb-2">
                        Upload Vehicle Image
                      </h3>
                      <p className="text-gray-500 mb-6">
                        Drag and drop an image here, or click to select
                      </p>
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-6 py-2 bg-blue-500 text-white rounded font-medium hover:bg-blue-600 transition-colors"
                      >
                        <Image size={16} className="inline mr-2" />
                        Choose Image
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-between mt-8">
              <div className="flex items-center gap-4">
                <button
                  onClick={handleTrackVehicle}
                  disabled={isTracking || (searchMethod === 'text' && !vehicleInfo.licensePlate.trim()) || (searchMethod === 'image' && !vehicleInfo.searchImage)}
                  className="px-6 py-2 bg-blue-500 text-white rounded font-medium hover:bg-blue-600 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2 transition-colors"
                >
                  {isTracking ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Tracking...</span>
                    </>
                  ) : (
                    <>
                      <Search size={16} />
                      <span>Track Vehicle</span>
                    </>
                  )}
                </button>
                
                {((searchMethod === 'text' && (vehicleInfo.licensePlate || vehicleInfo.brand || vehicleInfo.color)) || 
                  (searchMethod === 'image' && vehicleInfo.searchImage)) && (
                  <button
                    onClick={clearSearch}
                    className="px-4 py-2 text-gray-600 hover:text-gray-800 flex items-center gap-2 transition-colors hover:bg-gray-100 rounded"
                  >
                    <X size={16} />
                    Clear
                  </button>
                )}
              </div>

              {/* Search History */}
              {searchMethod === 'text' && searchHistory.length > 0 && (
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-gray-600">Recent:</span>
                  <div className="flex gap-2">
                    {searchHistory.slice(0, 3).map((item, index) => (
                      <button
                        key={index}
                        onClick={() => useHistorySearch(item)}
                        className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-sm text-gray-700 rounded-full transition-colors"
                      >
                        {item.licensePlate}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Tracking Results */}
          {trackingResults && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <Eye className="w-4 h-4 text-white" />
                  </div>
                  Tracking Results
                </h2>
                <div className={`px-4 py-2 rounded-lg text-sm font-medium ${
                  trackingResults.status === 'found' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {trackingResults.status === 'found' 
                    ? `✓ Found in ${trackingResults.totalCameras} locations` 
                    : '✗ Not Found'
                  }
                </div>
              </div>

              {/* Vehicle Summary */}
              <div className="bg-gray-50 rounded-lg p-6 mb-8 border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6 text-sm">
                  <div>
                    <span className="font-medium text-gray-700 block mb-2">Search Method:</span>
                    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
                      trackingResults.searchMethod === 'image' 
                        ? 'bg-purple-100 text-purple-700' 
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {trackingResults.searchMethod === 'image' ? <Image size={12} /> : <Search size={12} />}
                      {trackingResults.searchMethod === 'image' ? 'Image Search' : 'Text Search'}
                    </div>
                  </div>
                  
                  {trackingResults.searchMethod === 'text' && trackingResults.vehicle.licensePlate && (
                    <div>
                      <span className="font-medium text-gray-700 block mb-2">License Plate:</span>
                      <div className="text-lg font-bold text-blue-600">
                        {trackingResults.vehicle.licensePlate}
                      </div>
                    </div>
                  )}
                  
                  {trackingResults.vehicle.brand && (
                    <div>
                      <span className="font-medium text-gray-700 block mb-2">Brand:</span>
                      <div className="text-gray-800 font-medium">{trackingResults.vehicle.brand}</div>
                    </div>
                  )}
                  
                  {trackingResults.vehicle.color && (
                    <div>
                      <span className="font-medium text-gray-700 block mb-2">Color:</span>
                      <div className="text-gray-800 font-medium capitalize">{trackingResults.vehicle.color}</div>
                    </div>
                  )}
                  
                  <div>
                    <span className="font-medium text-gray-700 block mb-2">Last Seen:</span>
                    <div className="text-gray-800 font-medium">{formatTime(trackingResults.lastSeen)}</div>
                  </div>
                </div>
              </div>

              {/* Camera Detections Grid */}
              {trackingResults.detections.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {trackingResults.detections.map((detection, index) => (
                    <div 
                      key={detection.id}
                      className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 hover:translate-y-[-2px] hover:border-blue-300"
                    >
                      <div className="relative bg-gray-900 h-48 overflow-hidden">
                        <img
                          src={detection.vehicleImage}
                          alt={`Vehicle at ${detection.name}`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = detection.thumbnail;
                          }}
                        />
                        
                        {/* Detection Order Badge */}
                        <div className="absolute top-3 left-3 bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        
                        {/* Confidence Badge */}
                        <div className="absolute top-3 right-3 bg-black bg-opacity-80 text-white px-3 py-1 rounded-full text-xs font-medium">
                          {detection.confidence}% match
                        </div>

                        {/* Live Indicator */}
                        <div className="absolute bottom-3 right-3 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                          LIVE
                        </div>
                      </div>
                      
                      <div className="p-4 space-y-3">
                        <h3 className="font-semibold text-gray-800 text-lg">{detection.name}</h3>
                        
                        <div className="flex items-center text-sm text-gray-600 bg-gray-50 p-2 rounded">
                          <MapPin size={16} className="mr-2 text-blue-500" />
                          {detection.location}
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600 bg-gray-50 p-2 rounded">
                          <Clock size={16} className="mr-2 text-green-500" />
                          {formatTime(detection.detectionTime)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                  <Car size={64} className="mx-auto mb-6 opacity-30" />
                  <h3 className="text-2xl font-bold mb-3">Vehicle Not Found</h3>
                  <p className="text-lg">No detections found across all camera locations.</p>
                  <p className="text-sm mt-2 text-gray-400">Try adjusting your search parameters or check again later.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}